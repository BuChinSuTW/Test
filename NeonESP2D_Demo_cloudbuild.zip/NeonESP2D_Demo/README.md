# NEON ESP 2D Demo (Android No Root)

**cre : buchinsu 💢**

Ứng dụng minh họa overlay 2D độc lập, sử dụng dữ liệu nhân vật giả lập do C++20 sinh ra. Đây không phải công cụ ESP cho Free Fire.

## Tính năng
- Floating overlay trong suốt bằng `TYPE_APPLICATION_OVERLAY`.
- 4 hộp 2D chuyển động, nhãn BOT và thanh HP giả lập.
- Native C++20 qua JNI; không đọc process, không scan memory, không inject.
- Không yêu cầu root.
- Nút bật/tắt nằm trong Activity; overlay không nhận touch để tránh chặn thao tác của ứng dụng bên dưới.

## Yêu cầu build
- Android Studio tương thích Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35.
- Android NDK và CMake 3.22.1 (cài qua SDK Manager).

## Build APK
Mở thư mục `NeonESP2D_Demo` bằng Android Studio, chờ Gradle Sync, sau đó:
- Build > Build Bundle(s) / APK(s) > Build APK(s)

Hoặc từ thư mục dự án, nếu đã cài Gradle:
```bash
gradle assembleDebug
```

APK debug dự kiến tại:
`app/build/outputs/apk/debug/app-debug.apk`

## Cách dùng
1. Cài APK trên thiết bị Android 8.0 trở lên.
2. Mở ứng dụng.
3. Chọn **BẬT FLOATING OVERLAY**.
4. Android mở trang cấp quyền “Display over other apps”; bật quyền cho ứng dụng.
5. Quay lại ứng dụng. Overlay demo xuất hiện.
6. Mở lại ứng dụng và chọn **TẮT OVERLAY** để dừng.

## Ghi chú Android mới
- Android 13+ có thể hiển thị yêu cầu quyền thông báo. Nếu hệ thống yêu cầu, cho phép thông báo để thấy trạng thái dịch vụ.
- Một số ROM có cơ chế quản lý nền riêng; có thể cần cho phép ứng dụng chạy nền.
- `specialUse` foreground service được khai báo cho Android mới. Việc cài đặt/chạy vẫn cần kiểm tra trên thiết bị và phiên bản Android thực tế.

## Cấu trúc
```text
NeonESP2D_Demo/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── README.md
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/buchinsu/neonesp2d/
        │   ├── MainActivity.java
        │   ├── OverlayService.java
        │   └── NativeBridge.java
        └── cpp/
            ├── CMakeLists.txt
            └── synthetic_entities.cpp
```

## Trạng thái kiểm chứng
- Source được tạo theo cấu trúc Android Gradle + NDK.
- **Chưa xác nhận build thành công**: môi trường tạo source không chạy Android Gradle/NDK.
- Chưa kiểm tra trên điện thoại thật. Cần xác minh quyền overlay, foreground service, độ tương thích ROM, FPS và hiển thị khi xoay màn hình.
