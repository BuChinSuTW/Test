package com.buchinsu.neonesp2d;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {
    private static final String CHANNEL_ID = "neon_esp_demo";
    private WindowManager windowManager;
    private DemoOverlayView overlayView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable frameLoop = new Runnable() {
        @Override public void run() {
            if (overlayView != null) overlayView.invalidate();
            handler.postDelayed(this, 33L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(7, buildNotification());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlayView = new DemoOverlayView();
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;

        try {
            windowManager.addView(overlayView, params);
            handler.post(frameLoop);
        } catch (RuntimeException e) {
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(frameLoop);
        if (windowManager != null && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (RuntimeException ignored) {}
        }
        overlayView = null;
        stopForeground(true);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "NEON ESP demo", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Notification for the synthetic overlay demo");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder.setContentTitle("NEON ESP 2D Demo")
                .setContentText("Overlay đang hiển thị dữ liệu giả lập")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();
    }

    private final class DemoOverlayView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF box = new RectF();
        private final float[] entities = new float[4 * 6];

        DemoOverlayView() {
            super(OverlayService.this);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            float[] data = NativeBridge.getSyntheticEntities();
            if (data == null || data.length < 24) return;

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2));
            p.setColor(Color.rgb(0, 235, 255));
            p.setShadowLayer(dp(8), 0, 0, Color.rgb(0, 180, 255));

            for (int i = 0; i < 4; i++) {
                int k = i * 6;
                float x = data[k] * w;
                float y = data[k + 1] * h;
                float bw = data[k + 2] * w;
                float bh = data[k + 3] * h;
                float hp = Math.max(0f, Math.min(1f, data[k + 4]));
                int id = (int) data[k + 5];

                box.set(x - bw / 2f, y - bh / 2f, x + bw / 2f, y + bh / 2f);
                canvas.drawRoundRect(box, dp(5), dp(5), p);

                p.clearShadowLayer();
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(210, 5, 12, 25));
                canvas.drawRoundRect(box.left, box.top - dp(24), box.right, box.top - dp(5), dp(4), dp(4), p);

                p.setColor(Color.WHITE);
                p.setTextSize(dp(11));
                p.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                canvas.drawText(String.format(java.util.Locale.US, "BOT %02d", id), box.left + dp(4), box.top - dp(11), p);

                float barTop = box.bottom + dp(5);
                p.setColor(Color.argb(180, 30, 35, 45));
                canvas.drawRoundRect(box.left, barTop, box.right, barTop + dp(5), dp(3), dp(3), p);
                p.setColor(hp > 0.5f ? Color.rgb(30, 240, 150) : Color.rgb(255, 75, 100));
                canvas.drawRoundRect(box.left, barTop, box.left + bw * hp, barTop + dp(5), dp(3), dp(3), p);

                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(2));
                p.setColor(Color.rgb(0, 235, 255));
                p.setShadowLayer(dp(8), 0, 0, Color.rgb(0, 180, 255));
            }

            p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(190, 0, 0, 0));
            canvas.drawRoundRect(dp(12), dp(12), dp(208), dp(42), dp(8), dp(8), p);
            p.setColor(Color.rgb(0, 235, 255));
            p.setTextSize(dp(12));
            p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            canvas.drawText("NEON ESP 2D  •  SIMULATION", dp(20), dp(31), p);
        }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }
    }
}
