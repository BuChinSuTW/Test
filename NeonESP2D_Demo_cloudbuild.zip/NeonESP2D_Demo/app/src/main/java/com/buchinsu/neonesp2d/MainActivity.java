package com.buchinsu.neonesp2d;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 4102;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(22));
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setBackgroundColor(Color.rgb(8, 12, 24));

        TextView title = new TextView(this);
        title.setText("NEON ESP 2D");
        title.setTextColor(Color.rgb(0, 235, 255));
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);

        TextView subtitle = new TextView(this);
        subtitle.setText("OFFLINE VISUALIZATION  •  SYNTHETIC DATA ONLY");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(11);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(10), 0, dp(30));

        TextView info = new TextView(this);
        info.setText("Bản demo overlay 2D độc lập. Các hộp, nhãn và thanh HP được tạo bằng dữ liệu giả lập trong native C++.\n\nỨng dụng không đọc bộ nhớ, không inject và không tương tác với Free Fire.");
        info.setTextColor(Color.WHITE);
        info.setTextSize(15);
        info.setLineSpacing(dp(5), 1f);
        info.setPadding(0, 0, 0, dp(28));

        Button start = makeButton("BẬT FLOATING OVERLAY");
        start.setOnClickListener(v -> enableAndStart());

        Button stop = makeButton("TẮT OVERLAY");
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));

        TextView credit = new TextView(this);
        credit.setText("cre : buchinsu 💢");
        credit.setTextColor(Color.rgb(255, 55, 190));
        credit.setTextSize(13);
        credit.setGravity(Gravity.CENTER);
        credit.setPadding(0, dp(34), 0, 0);

        page.addView(title, matchWrap());
        page.addView(subtitle, matchWrap());
        page.addView(info, matchWrap());
        page.addView(start, matchWrapWithTop());
        page.addView(stop, matchWrapWithTop());
        page.addView(credit, matchWrap());
        setContentView(page);
    }

    private void enableAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_OVERLAY);
            return;
        }
        startOverlay();
    }

    private void startOverlay() {
        Intent intent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && Settings.canDrawOverlays(this)) {
            startOverlay();
        }
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.BLACK);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0, 220, 235)));
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams matchWrapWithTop() {
        LinearLayout.LayoutParams p = matchWrap();
        p.topMargin = dp(12);
        return p;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
