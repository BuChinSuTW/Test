package com.buchinsu.neonesp2d;

public final class NativeBridge {
    static {
        System.loadLibrary("neonesp2d");
    }

    private NativeBridge() {}

    // Four synthetic entities; each record: normalized centerX, centerY, width, height, hp, demoId.
    public static native float[] getSyntheticEntities();
}
