#include <jni.h>
#include <array>
#include <chrono>
#include <cmath>

namespace {
constexpr std::size_t kEntityCount = 4;
constexpr std::size_t kFieldsPerEntity = 6;
using Entity = std::array<float, kFieldsPerEntity>;

float clamp01(float v) {
    return v < 0.0F ? 0.0F : (v > 1.0F ? 1.0F : v);
}

float elapsed_seconds() {
    using clock = std::chrono::steady_clock;
    static const auto start = clock::now();
    return std::chrono::duration<float>(clock::now() - start).count();
}

std::array<Entity, kEntityCount> make_demo_entities(float t) {
    std::array<Entity, kEntityCount> out{};
    for (std::size_t i = 0; i < kEntityCount; ++i) {
        const float phase = t * (0.55F + 0.08F * static_cast<float>(i))
                          + static_cast<float>(i) * 1.57F;
        const float cx = 0.50F + 0.27F * std::sin(phase);
        const float cy = 0.48F + 0.22F * std::cos(phase * 0.73F);
        const float width = 0.075F;
        const float height = 0.205F;
        const float hp = clamp01(0.55F + 0.45F * std::sin(t * 0.35F + static_cast<float>(i)));
        out[i] = {clamp01(cx), clamp01(cy), width, height, hp, static_cast<float>(i + 1)};
    }
    return out;
}
} // namespace

extern "C"
JNIEXPORT jfloatArray JNICALL
Java_com_buchinsu_neonesp2d_NativeBridge_getSyntheticEntities(JNIEnv* env, jclass) {
    const auto entities = make_demo_entities(elapsed_seconds());
    std::array<jfloat, kEntityCount * kFieldsPerEntity> flat{};

    std::size_t cursor = 0;
    for (const auto& entity : entities) {
        for (float value : entity) flat[cursor++] = value;
    }

    jfloatArray result = env->NewFloatArray(static_cast<jsize>(flat.size()));
    if (result == nullptr) return nullptr;

    env->SetFloatArrayRegion(result, 0, static_cast<jsize>(flat.size()), flat.data());
    if (env->ExceptionCheck()) return nullptr;
    return result;
}
