cmake_minimum_required(VERSION 3.22.1)
project(neonesp2d LANGUAGES CXX)

add_library(neonesp2d SHARED synthetic_entities.cpp)

target_compile_features(neonesp2d PRIVATE cxx_std_20)
target_compile_options(neonesp2d PRIVATE -Wall -Wextra -Wpedantic)
target_link_libraries(neonesp2d PRIVATE log)
